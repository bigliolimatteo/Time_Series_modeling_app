shiny::runApp(system.file("shiny", "base-features", package = "dqshiny"))
